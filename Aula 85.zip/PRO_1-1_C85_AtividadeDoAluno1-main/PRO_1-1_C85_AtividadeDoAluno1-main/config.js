export const firebaseConfig = {
        apiKey: "AIzaSyBzO1GO35ffWJv415pE_RVCWWYZ3wI_iNA",
        authDomain: "app-de-historias-d1eee.firebaseapp.com",
        projectId: "app-de-historias-d1eee",
        storageBucket: "app-de-historias-d1eee.appspot.com",
        messagingSenderId: "778966956374",
        appId: "1:778966956374:web:0ae7afb52daf5f23033ef7"
}